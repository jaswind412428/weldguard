V3 report evidence; 205 fixed test images; class-aware IoU >= 0.5.
Training: final global_step 3265. Epoch field is a streaming trainer value.
Actual arguments: inspect training/train.log; unspecified flags are not verified.
Current environment.txt describes the export environment, not guaranteed historical state.
Examples include prior report images plus two largest/smallest per-image F1 changes.
Selected examples do not represent average performance. Use full-set metrics.
Includes derived GT/prediction overlays and prediction metadata; no raw dataset or model weights.
Generation settings: {"mode": "slow", "temperature": 0.7, "top_p": 0.9, "repetition_penalty": 1.1, "max_new_tokens": 512, "seed": 42}
Missing optional model results: []
